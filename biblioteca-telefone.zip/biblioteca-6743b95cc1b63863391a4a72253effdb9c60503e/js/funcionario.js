$(document).ready(function(){
            nomeUsuario();
            detalhesUsuario();
            editarUsuario();
            cadastrarTelefone();
            excluirPerfil();
            excluirTelefone();
        });
	function nomeUsuario(){
		$.ajax({
                    url: '../php/usuario/carrega-nome.php',
                    method: 'post',
                    data: {},
                    success: function(data){
                            $('#nomeUsuario').html(data);
                        
                }
          });
	}

	function detalhesUsuario(){
		$.ajax({
                    url: '../php/funcionario/detalhes-usuario-funcionario.php',
                    method: 'post',
                    data: {},
                    success: function(data){
                            $('#detalhes-usuario').html(data);
                        
                }
          });
	}

	function esconderAlertas(){
    	$('#alertSucessoEdit').hide();
        $('#alertPreencherTelefone').hide();
        $('#alertTelefoneRepetido').hide(); 
        $('#alertSucessoCadastro').hide();       
	}

	function editarUsuario(){
		$('#editarCadastro').click(function(){
            var validacao = false;
            var nome = -1;
            var email = -1;
            var endereco = -1;
            var senha = -1;
            var siape = -1;
            if( $('#nomeEdit').val().trim() !=""){
            	nome = $('#nomeEdit').val();
            	validacao = true;
            }

            if($('#emailEdit').val().trim() !=""){
            	email = $('#emailEdit').val();
            	validacao = true;
            }

            if($('#enderecoEdit').val().trim() !=""){
            	endereco = $('#enderecoEdit').val();
            	validacao = true;
            }
      
            if($('#senhaEdit').val().trim() !=""){
            	senha = $('#senhaEdit').val();
            	validacao = true;
            }

            if($('#siapeEdit').val().trim() !=""){
            	siape = $('#siapeEdit').val();
            	validacao = true;
            }


            if(validacao){
            	$.ajax({
                    url: '../php/funcionario/editar-funcionario.php',
                    method: 'post',
                    data: {nome:nome,email:email,siape:siape,senha:senha,endereco:endereco},
                    success: function(data){
                        detalhesUsuario();
                        $('#alertSucessoEdit').show();
                		}
          		});
            }
            


		});
	}

       function validaCampoTelefone(){
            var validacao = true;

            if($('#novoNumero').val().trim() ==""){
                validacao =  false;
            }

            return validacao; 
        }

    function cadastrarTelefone(){
        $('#cadastrarTelefone').click(function(){
            if(validaCampoTelefone()){
                var numero = $('#novoNumero').val();
                $.ajax({
                    url: '../php/insert_telefone.php',
                    method: 'post',
                    data: {numero:numero}, 
                    success: function(data){
                        alert(data);
                        esconderAlertas();                  
                    }
                });
            }
            else{
                alert('Preencha o campo');
            }
        });
    }    

	function excluirPerfil(){
            $('#excluir-perfil').click(function(){
               $.ajax({
                    url: '../php/funcionario/excluir-funcionario.php',
                    method: 'post',
                    data: {},
                    success: function(data){
                        window.location.href = '../views/index.php';
                
                    }
                });
                
            });
        }

    function excluirTelefone(){
            $('#excluir_telefone').click(function(){
               $.ajax({
                    url: '../php/excluir_telefone.php',
                    method: 'post',
                    data: {id_telefone:id_telefone}, 
                    success: function(data){
                        window.location.href = '../views/home_funcionario.php';
                
                    }
                });
                
            });
        }        