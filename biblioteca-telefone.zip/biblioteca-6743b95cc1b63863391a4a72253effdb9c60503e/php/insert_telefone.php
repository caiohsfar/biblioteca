<?php
    require_once('../classes/UsuarioDAO.class.php');
    require_once('../classes/Usuario.class.php');
   
   	session_start();
    $usuario = unserialize($_SESSION['usuario']);

    $id_usuario = $usuario->getId();   
    $numero = $_POST['numero'];

    $usuario_dao = new UsuarioDAO();

    if ($usuario_dao->telefoneCadastrado($numero)) {
    	echo "Telefone repetido";
    }
    else{
    	$usuario_dao->inserirTelefone($id_usuario,$numero);
    }

?> 