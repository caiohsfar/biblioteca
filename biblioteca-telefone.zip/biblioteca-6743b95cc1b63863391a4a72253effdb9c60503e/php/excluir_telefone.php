<?php
	require_once('../../classes/Funcionario.class.php');
	require_once('../../classes/UsuarioDAO.class.php');

	$id_telefone = $_POST['id_telefone'];

	$usuarioDAO = new UsuarioDAO();
	$usuarioDAO->excluirTelefone($id_telefone);
	header('Location:../../views/home_funcionario.php');

?>